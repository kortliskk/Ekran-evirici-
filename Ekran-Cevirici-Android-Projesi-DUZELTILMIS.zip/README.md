# ORBIT LENS — Ekran Çevirisi

ORBIT LENS, Android üzerinde başka uygulamalardaki görünür metni ekran paylaşımı izniyle algılayan ve seçilen dile çeviren bir ekran çeviricisidir.

## Özellikler

- Tam ekran çevirisi veya yalnızca seçilen dikdörtgen bölgenin çevirisi.
- Alan seçimi dikdörtgenini ortasından sürükleyerek taşıma, dört köşesinden büyütüp küçültme.
- Çeviri panelini başlığından sürükleyerek taşıma.
- Panelin sağ altındaki `BOYUTLANDIR` tutamacıyla pencereyi büyütüp küçültme.
- Paneli `●` düğmesiyle ekranın kenarında yuvarlak yüzen düğmeye küçültme; düğmeye dokunarak paneli tekrar açma.
- ML Kit OCR ve cihaz üzerinde çalışan çeviri modelleri.
- Varsayılan dil çifti: İngilizce → Türkçe.

## Kullanım

1. Uygulamadan kaynak ve hedef dili seçip canlı çeviriyi başlat.
2. Android'in ekran paylaşımı ve diğer uygulamaların üzerinde gösterme izinlerini onayla.
3. Yüzen paneli başka uygulamaya taşı. `ALAN` düğmesiyle bölge seç; çerçeveyi ortasından sürükle veya köşelerinden yeniden boyutlandır, sonra `BU ALANI KULLAN` seçeneğine dokun.
4. `TÜM` düğmesi tam ekran çevirisine geri döner.
5. `●` paneli kenarda küçük yüzen düğmeye indirir. Düğmeye dokunarak yeniden açılır.
6. Panelin sağ altındaki `BOYUTLANDIR` tutamacını sürükleyerek panel ölçülerini değiştir.

## Teknik notlar

- Ekran kareleri uygulama tarafından dosyaya kaydedilmez. OCR ve ML Kit çeviri işlemleri cihaz üzerinde yürütülür; dil modeli ilk kullanımda indirilebilir.
- OCR, Latin, Çince, Devanagari, Japonca ve Korece metin tanıma modüllerini kullanır. Bu, her dil/yazı sistemi için kusursuz tanıma garantisi vermez.
- DRM veya Android `FLAG_SECURE` kullanan bazı uygulamalar ekran yakalamayı engelleyebilir.
- Uygulama Android 10 ve üzeri için yapılandırılmıştır.

## Mağaza görseli

`branding/ORBIT-LENS-Feature-Graphic-1024x500.png` 1024×500 tanıtım görselidir.
