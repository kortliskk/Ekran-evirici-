package com.orbit.ekrancelviri

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.pm.ServiceInfo
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.android.gms.tasks.Task
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * ORBIT LENS foreground screen-capture service.
 * The user can translate the whole screen or crop OCR to a draggable region.
 * The result panel can be moved, resized and collapsed to a floating bubble.
 */
class CaptureService : Service() {

    private companion object {
        const val CHANNEL_ID = "orbit_lens_live"
        const val NOTIFICATION_ID = 901
        const val FRAME_INTERVAL_MS = 1_000L
        const val MODE_NONE = 0
        const val MODE_MOVE = 1
        const val MODE_TOP_LEFT = 2
        const val MODE_TOP_RIGHT = 3
        const val MODE_BOTTOM_LEFT = 4
        const val MODE_BOTTOM_RIGHT = 5
        const val MODE_DRAW = 6
        const val MODE_CANCEL = 7
        const val MODE_APPLY = 8
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val processingFrame = AtomicBoolean(false)

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var translator: Translator? = null
    private var windowManager: WindowManager? = null

    private var overlayRoot: LinearLayout? = null
    private var overlayOriginal: TextView? = null
    private var overlayTranslation: TextView? = null
    private var overlayStatus: TextView? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private var overlayBubble: TextView? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var selectorView: RegionSelectorView? = null
    private var panelHiddenForSelection = false

    private var isRunning = false
    private var sourceLanguage = "en"
    private var targetLanguage = "tr"
    private var lastRecognizedText = ""
    private var emptyFrameCount = 0
    private var recognizers: List<TextRecognizer> = emptyList()
    private var selectedRegion: Rect? = null
    private var screenWidthPx = 0
    private var screenHeightPx = 0
    private var panelWidthPx = 0
    private var panelHeightPx = 0
    private var panelX = 0
    private var panelY = 0
    private var hasPanelPosition = false
    private var currentStatus = "Çeviri hazırlanıyor…"

    private val frameLoop = object : Runnable {
        override fun run() {
            if (!isRunning) return
            captureOneFrame()
            mainHandler.postDelayed(this, FRAME_INTERVAL_MS)
        }
    }

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            isRunning = false
            mainHandler.post { stopSelf() }
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        createRecognizers()
        panelWidthPx = dp(360)
        panelHeightPx = dp(330)
        panelY = dp(76)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == AppContract.ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action != AppContract.ACTION_START) return START_NOT_STICKY

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                buildNotification("Ekran izni hazırlanıyor…"),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, buildNotification("Ekran izni hazırlanıyor…"))
        }
        sourceLanguage = intent.getStringExtra(AppContract.EXTRA_SOURCE_LANGUAGE) ?: "en"
        targetLanguage = intent.getStringExtra(AppContract.EXTRA_TARGET_LANGUAGE) ?: "tr"
        val resultCode = intent.getIntExtra(AppContract.EXTRA_RESULT_CODE, 0)
        val resultData = getResultData(intent)

        if (resultData == null) {
            showOverlayStatus("Ekran yakalama bilgisi alınamadı. Uygulamayı yeniden başlat.")
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, resultData)
            if (projection == null) throw IllegalStateException("Android ekran paylaşımı başlatılamadı.")
            projection?.registerCallback(projectionCallback, mainHandler)
            startVirtualDisplay()
            showOverlay()
            prepareTranslator()
        } catch (error: Exception) {
            showOverlayStatus("Başlatma hatası: ${error.localizedMessage ?: "bilinmeyen hata"}")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun getResultData(intent: Intent): Intent? {
        return if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(AppContract.EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            intent.getParcelableExtra(AppContract.EXTRA_RESULT_DATA)
        }
    }

    private fun createRecognizers() {
        recognizers = listOf(
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS),
            TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build()),
            TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build()),
            TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()),
            TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        )
    }

    private fun startVirtualDisplay() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)

        screenWidthPx = metrics.widthPixels
        screenHeightPx = metrics.heightPixels
        val density = metrics.densityDpi
        imageReader = ImageReader.newInstance(screenWidthPx, screenHeightPx, PixelFormat.RGBA_8888, 2)
        virtualDisplay = projection?.createVirtualDisplay(
            "OrbitLensCapture",
            screenWidthPx,
            screenHeightPx,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            mainHandler
        ) ?: throw IllegalStateException("Sanal ekran oluşturulamadı.")
    }

    private fun prepareTranslator() {
        val source = TranslateLanguage.fromLanguageTag(sourceLanguage)
            ?: throw IllegalArgumentException("Kaynak dil desteklenmiyor: $sourceLanguage")
        val target = TranslateLanguage.fromLanguageTag(targetLanguage)
            ?: throw IllegalArgumentException("Hedef dil desteklenmiyor: $targetLanguage")

        if (sourceLanguage == targetLanguage) {
            showOverlayStatus("Kaynak ve hedef dil aynı. Metinler aynen gösterilecek.")
            isRunning = true
            mainHandler.post(frameLoop)
            return
        }

        val options = TranslatorOptions.Builder()
            .setSourceLanguage(source)
            .setTargetLanguage(target)
            .build()
        translator = Translation.getClient(options)
        showOverlayStatus("Dil modeli hazırlanıyor. İlk kullanımda indirme gerekebilir…")
        updateNotification("Çeviri dili modeli indiriliyor…")

        translator?.downloadModelIfNeeded(DownloadConditions.Builder().build())
            ?.addOnSuccessListener {
                if (!isRunning) {
                    isRunning = true
                    showOverlayStatus("Canlı çeviri etkin. Ekranda metin aranıyor…")
                    updateNotification("Canlı ekran çevirisi etkin")
                    mainHandler.post(frameLoop)
                }
            }
            ?.addOnFailureListener { error ->
                showOverlayStatus("Çeviri modeli indirilemedi: ${error.localizedMessage ?: "internet bağlantısını kontrol et"}")
                updateNotification("Çeviri modeli indirilemedi")
                stopSelf()
            }
    }

    private fun captureOneFrame() {
        // Pause OCR while the full-screen area picker is visible.
        if (selectorView != null) return
        if (!isRunning || !processingFrame.compareAndSet(false, true)) return
        val image = try {
            imageReader?.acquireLatestImage()
        } catch (_: Exception) {
            null
        }
        if (image == null) {
            processingFrame.set(false)
            return
        }

        var bitmap: Bitmap? = null
        try {
            bitmap = imageToBitmap(image)
        } catch (error: Exception) {
            showOverlayStatus("Ekran görüntüsü alınamadı: ${error.localizedMessage ?: "bilinmeyen hata"}")
        } finally {
            image.close()
        }
        if (bitmap == null) {
            processingFrame.set(false)
            return
        }

        val cropped = try {
            cropToSelectedRegion(bitmap)
        } catch (error: Exception) {
            showOverlayStatus("Seçilen alan okunamadı; tüm ekran yeniden deneniyor.")
            null
        }
        val frameForOcr = cropped ?: bitmap
        runOcrWithFallback(frameForOcr, 0)
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val paddedWidth = image.width + rowPadding / pixelStride
        val paddedBitmap = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
        buffer.rewind()
        paddedBitmap.copyPixelsFromBuffer(buffer)
        val cropped = Bitmap.createBitmap(paddedBitmap, 0, 0, image.width, image.height)
        paddedBitmap.recycle()
        return cropped
    }

    /** Crop only the selected screen rectangle. A null rectangle means full-screen mode. */
    private fun cropToSelectedRegion(source: Bitmap): Bitmap {
        val requested = selectedRegion ?: return source
        val left = requested.left.coerceIn(0, source.width - 1)
        val top = requested.top.coerceIn(0, source.height - 1)
        val right = requested.right.coerceIn(left + 1, source.width)
        val bottom = requested.bottom.coerceIn(top + 1, source.height)
        val result = Bitmap.createBitmap(source, left, top, right - left, bottom - top)
        if (result !== source) source.recycle()
        return result
    }

    private fun runOcrWithFallback(bitmap: Bitmap, recognizerIndex: Int) {
        if (recognizerIndex >= recognizers.size) {
            onOcrFinished(bitmap, "")
            return
        }
        val inputImage = InputImage.fromBitmap(bitmap, 0)
        val task: Task<com.google.mlkit.vision.text.Text> = recognizers[recognizerIndex].process(inputImage)
        task.addOnSuccessListener { result ->
            val detected = result.text.trim()
            if (detected.isNotEmpty() || recognizerIndex == recognizers.lastIndex) {
                onOcrFinished(bitmap, detected)
            } else {
                runOcrWithFallback(bitmap, recognizerIndex + 1)
            }
        }.addOnFailureListener { error ->
            if (recognizerIndex < recognizers.lastIndex) {
                runOcrWithFallback(bitmap, recognizerIndex + 1)
            } else {
                showOverlayStatus("OCR işlemi başarısız: ${error.localizedMessage ?: "metin okunamadı"}")
                onOcrFinished(bitmap, "")
            }
        }
    }

    private fun onOcrFinished(bitmap: Bitmap, detectedText: String) {
        try { bitmap.recycle() } catch (_: Exception) { }
        val normalized = detectedText.replace(Regex("\\s+"), " ").trim().take(3500)
        if (normalized.isEmpty()) {
            emptyFrameCount++
            if (emptyFrameCount >= 3 && lastRecognizedText.isEmpty()) {
                showOverlayStatus(if (selectedRegion == null) "Ekranda okunabilir metin aranıyor…" else "Seçili bölgede okunabilir metin aranıyor…")
            }
            processingFrame.set(false)
            return
        }
        emptyFrameCount = 0
        if (normalized == lastRecognizedText) {
            processingFrame.set(false)
            return
        }
        lastRecognizedText = normalized
        showOverlayOriginal(normalized)

        if (sourceLanguage == targetLanguage) {
            showOverlayTranslation(normalized)
            processingFrame.set(false)
            return
        }
        val activeTranslator = translator
        if (activeTranslator == null) {
            showOverlayStatus("Çeviri motoru hazır değil.")
            processingFrame.set(false)
            return
        }
        activeTranslator.translate(normalized)
            .addOnSuccessListener { translated ->
                showOverlayTranslation(translated)
                processingFrame.set(false)
            }
            .addOnFailureListener { error ->
                showOverlayStatus("Çeviri yapılamadı: ${error.localizedMessage ?: "dil modelini kontrol et"}")
                lastRecognizedText = ""
                processingFrame.set(false)
            }
    }

    private fun showOverlay() {
        val wm = windowManager ?: return
        if (overlayRoot != null) return
        removeBubble()

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.argb(246, 12, 22, 40))
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), Color.rgb(45, 212, 191))
            }
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val heading = TextView(this).apply {
            text = "ORBIT LENS  •  CANLI"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(80, 224, 255))
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        header.addView(heading, LinearLayout.LayoutParams(0, dp(40), 1f))
        val regionButton = compactButton("ALAN") { openRegionSelector() }
        header.addView(regionButton, LinearLayout.LayoutParams(dp(62), dp(36)))
        val fullButton = compactButton("TÜM") {
            selectedRegion = null
            lastRecognizedText = ""
            showOverlayStatus("Tam ekran çevirisi etkin.")
        }
        header.addView(fullButton, LinearLayout.LayoutParams(dp(54), dp(36)).apply { leftMargin = dp(4) })
        val collapseButton = compactButton("●") { minimizeOverlay() }
        header.addView(collapseButton, LinearLayout.LayoutParams(dp(42), dp(36)).apply { leftMargin = dp(4) })
        val stopButton = compactButton("✕") { stopSelf() }
        header.addView(stopButton, LinearLayout.LayoutParams(dp(40), dp(36)).apply { leftMargin = dp(4) })
        panel.addView(header)

        heading.setOnTouchListener { _, event ->
            val params = overlayParams ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    dragStartX = params.x
                    dragStartY = params.y
                    dragTouchX = event.rawX
                    dragTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = (dragStartX + event.rawX - dragTouchX).toInt().coerceIn(0, max(0, screenWidthPx - params.width))
                    params.y = (dragStartY + event.rawY - dragTouchY).toInt().coerceIn(dp(8), max(dp(8), screenHeightPx - params.height - dp(8)))
                    panelX = params.x
                    panelY = params.y
                    try { wm.updateViewLayout(panel, params) } catch (_: Exception) { }
                    true
                }
                else -> false
            }
        }

        val status = TextView(this).apply {
            text = currentStatus
            textSize = 11f
            setTextColor(Color.rgb(165, 188, 212))
            setPadding(dp(4), dp(5), dp(4), dp(6))
        }
        panel.addView(status)
        overlayStatus = status

        val scroll = ScrollView(this).apply { isFillViewport = false }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val original = TextView(this).apply {
            text = "Algılanan metin burada görünecek."
            textSize = 12f
            setTextColor(Color.rgb(177, 194, 215))
            setPadding(dp(4), dp(5), dp(4), dp(8))
        }
        val translated = TextView(this).apply {
            text = "Çeviri bekleniyor…"
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(dp(4), dp(4), dp(4), dp(8))
        }
        content.addView(original)
        content.addView(translated)
        scroll.addView(content)
        panel.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        overlayOriginal = original
        overlayTranslation = translated

        val resizeHandle = TextView(this).apply {
            text = "↘  BOYUTLANDIR"
            textSize = 10f
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(80, 224, 255))
            setPadding(0, dp(4), dp(5), dp(2))
        }
        panel.addView(resizeHandle, LinearLayout.LayoutParams(dp(142), dp(28)).apply { gravity = Gravity.RIGHT })

        if (!hasPanelPosition) {
            panelX = max(0, (screenWidthPx - panelWidthPx) / 2)
            panelY = dp(76)
            hasPanelPosition = true
        }
        val params = WindowManager.LayoutParams(
            panelWidthPx.coerceIn(dp(220), max(dp(220), screenWidthPx - dp(16))),
            panelHeightPx.coerceIn(dp(150), max(dp(150), screenHeightPx - dp(24))),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_SECURE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = panelX.coerceIn(0, max(0, screenWidthPx - width))
            y = panelY.coerceIn(dp(8), max(dp(8), screenHeightPx - height - dp(8)))
        }
        overlayParams = params
        panelX = params.x
        panelY = params.y
        panelWidthPx = params.width
        panelHeightPx = params.height

        resizeHandle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    resizeStartWidth = params.width
                    resizeStartHeight = params.height
                    resizeTouchX = event.rawX
                    resizeTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val maxPanelWidth = max(dp(220), screenWidthPx - params.x - dp(8))
                    val maxPanelHeight = max(dp(150), screenHeightPx - params.y - dp(8))
                    params.width = (resizeStartWidth + event.rawX - resizeTouchX).toInt().coerceIn(dp(220), maxPanelWidth)
                    params.height = (resizeStartHeight + event.rawY - resizeTouchY).toInt().coerceIn(dp(150), maxPanelHeight)
                    panelWidthPx = params.width
                    panelHeightPx = params.height
                    try { wm.updateViewLayout(panel, params) } catch (_: Exception) { }
                    true
                }
                else -> false
            }
        }

        overlayRoot = panel
        try {
            wm.addView(panel, params)
        } catch (error: Exception) {
            overlayRoot = null
            showOverlayStatus("Üst katman açılamadı: ${error.localizedMessage ?: "izinleri kontrol et"}")
        }
    }

    private var dragStartX = 0
    private var dragStartY = 0
    private var dragTouchX = 0f
    private var dragTouchY = 0f
    private var resizeStartWidth = 0
    private var resizeStartHeight = 0
    private var resizeTouchX = 0f
    private var resizeTouchY = 0f

    private fun compactButton(label: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 9f
            isAllCaps = false
            minWidth = 0
            minimumWidth = 0
            minHeight = 0
            minimumHeight = 0
            setPadding(dp(2), 0, dp(2), 0)
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(Color.rgb(28, 48, 72))
                cornerRadius = dp(9).toFloat()
                setStroke(dp(1), Color.rgb(45, 212, 191))
            }
            setOnClickListener { action() }
        }
    }

    private fun minimizeOverlay() {
        val panel = overlayRoot ?: return
        try { windowManager?.removeView(panel) } catch (_: Exception) { }
        overlayRoot = null
        showBubble()
    }

    private fun showBubble() {
        val wm = windowManager ?: return
        if (overlayBubble != null) return
        val bubble = TextView(this).apply {
            text = "文"
            textSize = 25f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(0, 190, 225), Color.rgb(108, 70, 245))).apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(2), Color.WHITE)
            }
            elevation = dp(8).toFloat()
        }
        val params = WindowManager.LayoutParams(
            dp(58), dp(58),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_SECURE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = max(dp(8), screenWidthPx - dp(74))
            y = dp(150)
        }
        bubbleParams = params
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        bubble.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    params.x = (startX + dx).toInt().coerceIn(0, max(0, screenWidthPx - dp(58)))
                    params.y = (startY + dy).toInt().coerceIn(dp(8), max(dp(8), screenHeightPx - dp(66)))
                    try { wm.updateViewLayout(bubble, params) } catch (_: Exception) { }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        restoreOverlay()
                    } else {
                        params.x = if (params.x + dp(29) < screenWidthPx / 2) dp(4) else max(dp(4), screenWidthPx - dp(62))
                        try { wm.updateViewLayout(bubble, params) } catch (_: Exception) { }
                    }
                    true
                }
                else -> true
            }
        }
        overlayBubble = bubble
        try { wm.addView(bubble, params) } catch (_: Exception) { overlayBubble = null }
    }

    private fun restoreOverlay() {
        removeBubble()
        showOverlay()
    }

    private fun removeBubble() {
        val bubble = overlayBubble
        if (bubble != null) {
            try { windowManager?.removeView(bubble) } catch (_: Exception) { }
        }
        overlayBubble = null
        bubbleParams = null
    }

    private fun openRegionSelector() {
        val wm = windowManager ?: return
        if (selectorView != null) return
        // Temporarily hide the result panel so it does not cover text being selected.
        val visiblePanel = overlayRoot
        if (visiblePanel != null && !panelHiddenForSelection) {
            try {
                wm.removeView(visiblePanel)
                panelHiddenForSelection = true
            } catch (_: Exception) { }
        }
        if (screenWidthPx <= 0 || screenHeightPx <= 0) {
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(metrics)
            screenWidthPx = metrics.widthPixels
            screenHeightPx = metrics.heightPixels
        }
        val selector = RegionSelectorView(
            screenWidthPx,
            screenHeightPx,
            selectedRegion,
            onCancel = {
                removeRegionSelector()
                restorePanelAfterSelection()
                showOverlayStatus("Önceki çeviri alanı korunuyor.")
            },
            onApply = { rect ->
                selectedRegion = Rect(rect)
                lastRecognizedText = ""
                removeRegionSelector()
                restorePanelAfterSelection()
                showOverlayStatus("Seçili alan etkin. Yalnızca çerçeve içindeki yazılar çevriliyor.")
            }
        )
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        selectorView = selector
        try {
            wm.addView(selector, params)
        } catch (error: Exception) {
            selectorView = null
            restorePanelAfterSelection()
            showOverlayStatus("Alan seçimi açılamadı: ${error.localizedMessage ?: "izinleri kontrol et"}")
        }
    }

    private fun removeRegionSelector() {
        val selector = selectorView
        if (selector != null) {
            try { windowManager?.removeView(selector) } catch (_: Exception) { }
        }
        selectorView = null
    }

    private fun restorePanelAfterSelection() {
        if (!panelHiddenForSelection) return
        val panel = overlayRoot ?: return
        val params = overlayParams ?: return
        try {
            windowManager?.addView(panel, params)
            panelHiddenForSelection = false
        } catch (error: Exception) {
            showOverlayStatus("Çeviri paneli geri açılamadı: ${error.localizedMessage ?: "bilinmeyen hata"}")
        }
    }

    /** Transparent full-screen selection layer with movable and corner-resizable bounds. */
    private inner class RegionSelectorView(
        private val viewWidth: Int,
        private val viewHeight: Int,
        initialRegion: Rect?,
        private val onCancel: () -> Unit,
        private val onApply: (Rect) -> Unit
    ) : View(this@CaptureService) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val bounds = RectF()
        private var gestureMode = MODE_NONE
        private var downX = 0f
        private var downY = 0f
        private var startRect = RectF()
        private val handleRadius = dp(13).toFloat()
        private val minimumSize = dp(72).toFloat()

        init {
            setLayerType(View.LAYER_TYPE_SOFTWARE, null)
            if (initialRegion != null) {
                bounds.set(initialRegion.left.toFloat(), initialRegion.top.toFloat(), initialRegion.right.toFloat(), initialRegion.bottom.toFloat())
            } else {
                val left = viewWidth * 0.12f
                val top = viewHeight * 0.22f
                bounds.set(left, top, viewWidth * 0.88f, viewHeight * 0.72f)
            }
            clampBounds()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            // A subtle transparent shade preserves the underlying text while marking the selection UI.
            paint.style = Paint.Style.FILL
            paint.color = Color.argb(28, 0, 0, 0)
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)

            paint.color = Color.argb(35, 45, 212, 191)
            canvas.drawRect(bounds, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = dp(3).toFloat()
            paint.color = Color.rgb(45, 212, 191)
            canvas.drawRoundRect(bounds, dp(8).toFloat(), dp(8).toFloat(), paint)

            paint.style = Paint.Style.FILL
            paint.color = Color.WHITE
            val points = arrayOf(
                bounds.left to bounds.top, bounds.right to bounds.top,
                bounds.left to bounds.bottom, bounds.right to bounds.bottom
            )
            points.forEach { (x, y) -> canvas.drawCircle(x, y, handleRadius, paint) }
            paint.color = Color.rgb(0, 150, 175)
            points.forEach { (x, y) -> canvas.drawCircle(x, y, handleRadius * 0.55f, paint) }

            val topBar = RectF(dp(12).toFloat(), dp(18).toFloat(), width - dp(12).toFloat(), dp(66).toFloat())
            paint.color = Color.argb(238, 12, 22, 40)
            canvas.drawRoundRect(topBar, dp(12).toFloat(), dp(12).toFloat(), paint)
            drawTextCentered(canvas, "ÇEVRİLECEK BÖLGEYİ AYARLA", width / 2f, dp(47).toFloat(), dp(13).toFloat(), Color.WHITE)

            val bar = bottomBar()
            paint.color = Color.argb(238, 12, 22, 40)
            canvas.drawRoundRect(bar, dp(14).toFloat(), dp(14).toFloat(), paint)
            val cancel = cancelButton()
            val apply = applyButton()
            paint.color = Color.rgb(42, 58, 82)
            canvas.drawRoundRect(cancel, dp(9).toFloat(), dp(9).toFloat(), paint)
            paint.color = Color.rgb(25, 184, 170)
            canvas.drawRoundRect(apply, dp(9).toFloat(), dp(9).toFloat(), paint)
            drawTextCentered(canvas, "VAZGEÇ", cancel.centerX(), cancel.centerY() + dp(5).toFloat(), dp(12).toFloat(), Color.WHITE)
            drawTextCentered(canvas, "BU ALANI KULLAN", apply.centerX(), apply.centerY() + dp(5).toFloat(), dp(11).toFloat(), Color.rgb(4, 24, 35))
            drawTextCentered(canvas, "Ortadan sürükle: taşı  •  Köşeler: boyutlandır", width / 2f, bar.top - dp(10).toFloat(), dp(10).toFloat(), Color.WHITE)
        }

        private fun bottomBar() = RectF(dp(12).toFloat(), height - dp(76).toFloat(), width - dp(12).toFloat(), height - dp(12).toFloat())
        private fun cancelButton() = RectF(dp(22).toFloat(), height - dp(66).toFloat(), width / 2f - dp(6), height - dp(22).toFloat())
        private fun applyButton() = RectF(width / 2f + dp(6), height - dp(66).toFloat(), width - dp(22).toFloat(), height - dp(22).toFloat())

        private fun drawTextCentered(canvas: Canvas, text: String, x: Float, y: Float, size: Float, color: Int) {
            paint.style = Paint.Style.FILL
            paint.textAlign = Paint.Align.CENTER
            paint.typeface = Typeface.create("sans-serif", Typeface.BOLD)
            paint.textSize = size
            paint.color = color
            canvas.drawText(text, x, y, paint)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            val x = event.x
            val y = event.y
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = x
                    downY = y
                    startRect = RectF(bounds)
                    if (cancelButton().contains(x, y)) {
                        gestureMode = MODE_CANCEL
                    } else if (applyButton().contains(x, y)) {
                        gestureMode = MODE_APPLY
                    } else {
                        gestureMode = when {
                            near(x, y, bounds.left, bounds.top) -> MODE_TOP_LEFT
                            near(x, y, bounds.right, bounds.top) -> MODE_TOP_RIGHT
                            near(x, y, bounds.left, bounds.bottom) -> MODE_BOTTOM_LEFT
                            near(x, y, bounds.right, bounds.bottom) -> MODE_BOTTOM_RIGHT
                            bounds.contains(x, y) -> MODE_MOVE
                            else -> MODE_DRAW
                        }
                        if (gestureMode == MODE_DRAW) bounds.set(x, y, x, y)
                    }
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = x - downX
                    val dy = y - downY
                    when (gestureMode) {
                        MODE_MOVE -> {
                            bounds.set(startRect)
                            bounds.offset(dx, dy)
                        }
                        MODE_TOP_LEFT -> { bounds.left = startRect.left + dx; bounds.top = startRect.top + dy }
                        MODE_TOP_RIGHT -> { bounds.right = startRect.right + dx; bounds.top = startRect.top + dy }
                        MODE_BOTTOM_LEFT -> { bounds.left = startRect.left + dx; bounds.bottom = startRect.bottom + dy }
                        MODE_BOTTOM_RIGHT -> { bounds.right = startRect.right + dx; bounds.bottom = startRect.bottom + dy }
                        MODE_DRAW -> bounds.set(downX, downY, x, y)
                    }
                    normalizeBounds()
                    clampBounds()
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    when (gestureMode) {
                        MODE_CANCEL -> if (cancelButton().contains(x, y)) onCancel()
                        MODE_APPLY -> if (applyButton().contains(x, y)) {
                            normalizeBounds()
                            clampBounds()
                            if (bounds.width() >= minimumSize && bounds.height() >= minimumSize) {
                                onApply(Rect(bounds.left.toInt(), bounds.top.toInt(), bounds.right.toInt(), bounds.bottom.toInt()))
                            }
                        }
                    }
                    gestureMode = MODE_NONE
                    invalidate()
                    return true
                }
            }
            return true
        }

        private fun near(x: Float, y: Float, cx: Float, cy: Float): Boolean =
            abs(x - cx) <= handleRadius * 1.8f && abs(y - cy) <= handleRadius * 1.8f

        private fun normalizeBounds() {
            if (bounds.left > bounds.right) { val temp = bounds.left; bounds.left = bounds.right; bounds.right = temp }
            if (bounds.top > bounds.bottom) { val temp = bounds.top; bounds.top = bounds.bottom; bounds.bottom = temp }
        }

        private fun clampBounds() {
            val maxX = min(width.takeIf { it > 0 }?.toFloat() ?: viewWidth.toFloat(), viewWidth.toFloat())
            val maxY = min(height.takeIf { it > 0 }?.toFloat() ?: viewHeight.toFloat(), viewHeight.toFloat())
            val w = bounds.width().coerceAtLeast(minimumSize)
            val h = bounds.height().coerceAtLeast(minimumSize)
            if (bounds.left < 0f) bounds.offset(-bounds.left, 0f)
            if (bounds.top < dp(76).toFloat()) bounds.offset(0f, dp(76).toFloat() - bounds.top)
            if (bounds.right > maxX) bounds.offset(maxX - bounds.right, 0f)
            if (bounds.bottom > maxY - dp(92)) bounds.offset(0f, maxY - dp(92) - bounds.bottom)
            if (bounds.width() < w) bounds.right = min(maxX, bounds.left + w)
            if (bounds.height() < h) bounds.bottom = min(maxY - dp(92), bounds.top + h)
        }

    }

    private fun showOverlayStatus(message: String) {
        mainHandler.post {
            currentStatus = message
            overlayStatus?.text = message
        }
    }

    private fun showOverlayOriginal(text: String) {
        mainHandler.post { overlayOriginal?.text = "Kaynak metin: $text" }
    }

    private fun showOverlayTranslation(text: String) {
        mainHandler.post {
            overlayTranslation?.text = text
            val mode = if (selectedRegion == null) "Tam ekran" else "Seçili alan"
            val status = "$mode  •  ${sourceLanguage.uppercase()} → ${targetLanguage.uppercase()}"
            currentStatus = status
            overlayStatus?.text = status
        }
    }

    private fun buildNotification(status: String): Notification {
        val stopIntent = Intent(this, CaptureService::class.java).setAction(AppContract.ACTION_STOP)
        val stopPendingIntent = PendingIntent.getService(
            this, 77, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle("ORBIT LENS")
            .setContentText(status)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_pause, "Durdur", stopPendingIntent).build())
            .build()
    }

    private fun updateNotification(status: String) {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(status))
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(CHANNEL_ID, "ORBIT LENS canlı çeviri", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Ekran çevirisi çalışırken gösterilir."
        }
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
    }

    override fun onDestroy() {
        isRunning = false
        mainHandler.removeCallbacks(frameLoop)
        try { virtualDisplay?.release() } catch (_: Exception) { }
        virtualDisplay = null
        try { imageReader?.close() } catch (_: Exception) { }
        imageReader = null
        try {
            projection?.unregisterCallback(projectionCallback)
            projection?.stop()
        } catch (_: Exception) { }
        projection = null
        try { translator?.close() } catch (_: Exception) { }
        translator = null
        recognizers.forEach { recognizer -> try { recognizer.close() } catch (_: Exception) { } }
        recognizers = emptyList()
        removeRegionSelector()
        removeBubble()
        removeOverlay()
        super.onDestroy()
    }

    private fun removeOverlay() {
        val view = overlayRoot
        if (view != null) try { windowManager?.removeView(view) } catch (_: Exception) { }
        overlayRoot = null
        overlayOriginal = null
        overlayTranslation = null
        overlayStatus = null
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
