package com.orbit.ekrancelviri

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView

/** ORBIT LENS setup screen: language selection and Android permission flow. */
class MainActivity : Activity() {

    private companion object {
        const val REQUEST_OVERLAY = 4101
        const val REQUEST_CAPTURE = 4102
    }

    private lateinit var sourceSpinner: Spinner
    private lateinit var targetSpinner: Spinner
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 16, 31)
        window.navigationBarColor = Color.rgb(8, 16, 31)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(24))
            setBackgroundColor(Color.rgb(8, 16, 31))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(root)
        }

        // Uygulama içi kapak görseli (Play Store tanıtım görseliyle aynı marka dili).
        val cover = ImageView(this).apply {
            setImageResource(R.drawable.orbit_lens_cover)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = roundedBackground(Color.rgb(18, 31, 51), Color.rgb(43, 67, 91), 18)
            clipToOutline = true
            contentDescription = "ORBIT LENS tanıtım görseli"
        }
        root.addView(cover, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(154)
        ).apply { bottomMargin = dp(18) })

        val brandRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = TextView(this).apply {
            text = "A↔文"
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(0, 190, 220), Color.rgb(104, 72, 242))).apply {
                cornerRadius = dp(16).toFloat()
            }
        }
        brandRow.addView(logo, LinearLayout.LayoutParams(dp(60), dp(60)))
        val nameColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), 0, 0, 0)
        }
        nameColumn.addView(TextView(this).apply {
            text = "ORBIT LENS"
            textSize = 25f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        })
        nameColumn.addView(TextView(this).apply {
            text = "SCREEN TRANSLATOR"
            textSize = 10f
            letterSpacing = 0.16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(80, 224, 255))
        })
        brandRow.addView(nameColumn)
        root.addView(brandRow)

        val subtitle = TextView(this).apply {
            text = "Ekranda gördüğünü anında anla. Tam ekranı veya yalnızca seçtiğin bir bölgeyi çevir."
            textSize = 15f
            setTextColor(Color.rgb(183, 198, 220))
            setPadding(0, dp(16), 0, dp(20))
        }
        root.addView(subtitle)

        val languageCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(12), dp(15), dp(15))
            background = roundedBackground(Color.rgb(18, 31, 51), Color.rgb(43, 67, 91), 16)
        }
        val cardHeading = TextView(this).apply {
            text = "ÇEVİRİ DİLLERİ"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(80, 224, 255))
            setPadding(0, 0, 0, dp(7))
        }
        languageCard.addView(cardHeading)
        addFieldLabel(languageCard, "Kaynak dil")
        sourceSpinner = createLanguageSpinner()
        languageCard.addView(sourceSpinner, matchWidthWrap())
        sourceSpinner.setSelection(AppLanguages.all.indexOfFirst { it.code == "en" })
        addFieldLabel(languageCard, "Çeviri dili")
        targetSpinner = createLanguageSpinner()
        languageCard.addView(targetSpinner, matchWidthWrap())
        targetSpinner.setSelection(AppLanguages.all.indexOfFirst { it.code == "tr" })
        root.addView(languageCard, matchWidthWrap())

        val startButton = Button(this).apply {
            text = "CANLI ÇEVİRİYİ BAŞLAT  →"
            textSize = 14f
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(5, 22, 34))
            background = roundedBackground(Color.rgb(45, 212, 191), Color.rgb(45, 212, 191), 14)
            setOnClickListener { beginPermissionFlow() }
        }
        root.addView(startButton, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(56)).apply {
            topMargin = dp(18)
        })

        val stopButton = Button(this).apply {
            text = "ÇEVİRİYİ DURDUR"
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = roundedBackground(Color.rgb(35, 52, 76), Color.rgb(54, 76, 104), 13)
            setOnClickListener {
                stopCaptureService()
                setStatus("Çeviri durduruldu.")
            }
        }
        root.addView(stopButton, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)).apply {
            topMargin = dp(8)
        })

        statusText = TextView(this).apply {
            text = "Hazır  •  Varsayılan dil çifti: İngilizce → Türkçe"
            textSize = 13f
            setTextColor(Color.rgb(181, 199, 220))
            setPadding(dp(13), dp(13), dp(13), dp(13))
            background = roundedBackground(Color.rgb(16, 29, 47), Color.rgb(36, 57, 81), 12)
        }
        root.addView(statusText, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(15)
        })

        val features = TextView(this).apply {
            text = "✦  TAM EKRAN VE BÖLGE SEÇİMİ\n" +
                "✦  TAŞINABİLİR VE BOYUTLANDIRILABİLİR ÇEVİRİ PENCERESİ\n" +
                "✦  TEK DOKUNUŞLA KÜÇÜK YÜZEN BALON\n\n" +
                "Çeviri penceresindeki ALAN düğmesiyle bir dikdörtgen seç. Köşelerinden büyütüp küçültebilir, ortasından sürükleyebilirsin."
            textSize = 12f
            setLineSpacing(dp(5).toFloat(), 1f)
            setTextColor(Color.rgb(151, 173, 199))
            setPadding(dp(4), dp(17), dp(4), dp(13))
        }
        root.addView(features)

        val note = TextView(this).apply {
            text = "İlk kullanımda seçilen dillerin çeviri modeli indirilebilir. Ekran paylaşımı ve diğer uygulamaların üzerinde gösterme izinleri gerekir. Ekran kareleri dosyaya kaydedilmez."
            textSize = 11f
            setTextColor(Color.rgb(125, 148, 177))
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = roundedBackground(Color.rgb(14, 25, 42), Color.rgb(34, 50, 72), 12)
        }
        root.addView(note, matchWidthWrap())
        setContentView(scroll)
    }

    private fun addFieldLabel(parent: LinearLayout, label: String) {
        parent.addView(TextView(this).apply {
            text = label
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(211, 224, 240))
            setPadding(0, dp(7), 0, dp(6))
        })
    }

    private fun createLanguageSpinner(): Spinner {
        val spinner = Spinner(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, AppLanguages.all.map { it.title })
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
        return spinner
    }

    private fun roundedBackground(fill: Int, stroke: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radiusDp).toFloat()
        setStroke(dp(1), stroke)
    }

    private fun beginPermissionFlow() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            setStatus("Devam etmek için ORBIT LENS için 'Diğer uygulamaların üzerinde göster' iznini aç.")
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivityForResult(intent, REQUEST_OVERLAY)
            return
        }
        requestScreenCaptureConsent()
    }

    private fun requestScreenCaptureConsent() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        setStatus("Android ekran paylaşımı izni bekleniyor.")
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
    }

    @Deprecated("Android's consent activities are handled through onActivityResult for API 29 compatibility.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_OVERLAY -> {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
                    requestScreenCaptureConsent()
                } else {
                    setStatus("Üst katman izni verilmedi. Canlı çeviri başlatılamadı.")
                }
            }
            REQUEST_CAPTURE -> {
                if (resultCode == RESULT_OK && data != null) {
                    val source = AppLanguages.all[sourceSpinner.selectedItemPosition].code
                    val target = AppLanguages.all[targetSpinner.selectedItemPosition].code
                    val serviceIntent = Intent(this, CaptureService::class.java).apply {
                        action = AppContract.ACTION_START
                        putExtra(AppContract.EXTRA_RESULT_CODE, resultCode)
                        putExtra(AppContract.EXTRA_RESULT_DATA, data)
                        putExtra(AppContract.EXTRA_SOURCE_LANGUAGE, source)
                        putExtra(AppContract.EXTRA_TARGET_LANGUAGE, target)
                    }
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent) else startService(serviceIntent)
                        setStatus("ORBIT LENS başlatılıyor. Diğer uygulamaya geçebilirsin.")
                    } catch (error: Exception) {
                        setStatus("Başlatma hatası: ${error.localizedMessage ?: "bilinmeyen hata"}")
                    }
                } else {
                    setStatus("Ekran paylaşımı izni verilmedi; çeviri başlamadı.")
                }
            }
        }
    }

    private fun stopCaptureService() {
        startService(Intent(this, CaptureService::class.java).setAction(AppContract.ACTION_STOP))
    }

    private fun setStatus(message: String) {
        if (::statusText.isInitialized) statusText.text = message
    }

    private fun matchWidthWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
