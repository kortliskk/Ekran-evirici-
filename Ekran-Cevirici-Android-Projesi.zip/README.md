# Ekran Çevirici (Android)

Android 10+ tabletler için hazırlanmış, ekran üzerindeki metni yaklaşık saniyede bir algılayıp değiştiğinde çeviren yerel Android uygulaması.

## Özellikler

- Varsayılan dil: İngilizce → Türkçe.
- Kaynak ve hedef dil seçimi.
- Ekran paylaşımı izniyle başka uygulamaların üzerindeki metni yakalama.
- Sürüklenebilir, yarı saydam çeviri paneli.
- Metin aynı kaldığı sürece tekrar çeviri yapmama.
- OCR ve çeviri cihaz üzerinde çalışır; ekran görüntüleri dosyaya kaydedilmez ve OCR metni bir sunucuya gönderilmez.
- İlk kullanımda seçilen dil çiftinin çeviri modeli indirilir. İlk indirme için internet gerekir.

## Dil desteği hakkında önemli not

ML Kit Translation'ın listelenen 59 dili seçeneklerde sunulmuştur. Bu, dünyadaki her dili kapsadığı anlamına gelmez. OCR tarafında Latin, Çince, Devanagari, Japonca ve Korece yazı sistemleri için tanıyıcılar eklenmiştir. Arapça, Kiril ve diğer bazı yazı sistemleri için bu ilk sürümde OCR desteği yoktur; bu diller seçilebilir olsa da ekrandaki yazıyı doğru algılamayabilir.

## GitHub Actions ile APK oluşturma

1. Bu ZIP içindeki dosyaları bir GitHub deposunun kök dizinine yükle.
2. Depoda `main` dalı bulunduğundan emin ol.
3. GitHub deposunda **Actions** sekmesini aç.
4. Soldan **Ekran Cevirici Android APK** iş akışını seç ve **Run workflow** düğmesine bas.
5. İşlem tamamlanınca **EKRAN-CEVIRICI-APK** artifact dosyasını indirip ZIP'ten çıkar. İçinde `app-debug.apk` bulunur.

İş akışı ayrıca `main` dalına her push yapıldığında otomatik çalışır.

## Android tablette ilk kullanım

1. APK'yı yükle ve aç.
2. Kaynak/hedef dilleri seç.
3. **Canlı ekran çevirisini başlat** düğmesine bas.
4. Android ayarlarında uygulama için **Diğer uygulamaların üzerinde göster** iznini ver.
5. Android'in ekran yakalama onayını kabul et.
6. Çevirmek istediğin uygulamaya geç. Çeviri panelini üst başlığından sürükleyebilirsin. Paneldeki veya bildirimdeki **Durdur** düğmesi yakalamayı sonlandırır.

## Teknik notlar

- Native Kotlin/Android uygulamasıdır; `pytesseract` ve `mss` masaüstü Python kütüphaneleridir ve Android'de başka uygulamaların ekranını yakalamak için uygun değildir. Bu nedenle Android MediaProjection ve ML Kit kullanılmıştır.
- Android 10 (API 29) ve üzeri hedeflenir.
- Bu depo kaynak kodu ve GitHub Actions yapılandırmasını içerir. Bu çalışma ortamında Android SDK/Gradle derlemesi çalıştırılamadığı için APK burada önceden derlenmiş değildir; APK GitHub Actions üzerinden oluşturulur.
