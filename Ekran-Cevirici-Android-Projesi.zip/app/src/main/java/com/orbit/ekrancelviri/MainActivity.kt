package com.orbit.ekrancelviri

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView

/** Main screen: language selection and Android's two required consent screens. */
class MainActivity : Activity() {

    private companion object {
        const val REQUEST_OVERLAY = 4101
        const val REQUEST_CAPTURE = 4102
        const val REQUEST_NOTIFICATIONS = 4103
    }

    private lateinit var sourceSpinner: Spinner
    private lateinit var targetSpinner: Spinner
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 24, 39)
        window.navigationBarColor = Color.rgb(16, 24, 39)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(24))
            setBackgroundColor(Color.rgb(16, 24, 39))
        }

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(root)
        }

        val title = TextView(this).apply {
            text = "EKRAN ÇEVİRİCİ"
            textSize = 27f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "Ekrandaki yazıları algılar ve seçtiğin dile canlı olarak çevirir."
            textSize = 15f
            setTextColor(Color.rgb(190, 202, 218))
            setPadding(0, dp(8), 0, dp(22))
        }
        root.addView(subtitle)

        addFieldLabel(root, "KAYNAK DİL")
        sourceSpinner = createLanguageSpinner()
        root.addView(sourceSpinner, matchWidthWrap())
        sourceSpinner.setSelection(AppLanguages.all.indexOfFirst { it.code == "en" })

        addFieldLabel(root, "ÇEVRİLECEK DİL")
        targetSpinner = createLanguageSpinner()
        root.addView(targetSpinner, matchWidthWrap())
        targetSpinner.setSelection(AppLanguages.all.indexOfFirst { it.code == "tr" })

        val startButton = Button(this).apply {
            text = "CANLI EKRAN ÇEVİRİSİNİ BAŞLAT"
            textSize = 14f
            isAllCaps = false
            setTextColor(Color.rgb(7, 24, 34))
            setBackgroundColor(Color.rgb(45, 212, 191))
            setOnClickListener { beginPermissionFlow() }
        }
        val startParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(56)
        ).apply { topMargin = dp(25) }
        root.addView(startButton, startParams)

        val stopButton = Button(this).apply {
            text = "ÇEVİRİYİ DURDUR"
            isAllCaps = false
            setOnClickListener {
                stopCaptureService()
                setStatus("Çeviri durduruldu.")
            }
        }
        val stopParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(48)
        ).apply { topMargin = dp(8) }
        root.addView(stopButton, stopParams)

        statusText = TextView(this).apply {
            text = "Hazır. Varsayılan dil çifti: İngilizce → Türkçe."
            textSize = 14f
            setTextColor(Color.rgb(190, 202, 218))
            setPadding(0, dp(20), 0, dp(15))
        }
        root.addView(statusText)

        val note = TextView(this).apply {
            text = "İlk kullanımda çeviri modeli internet üzerinden indirilir. Sonrasında çeviri cihazda yapılır. " +
                "Başlatırken ekran paylaşımı izni ve diğer uygulamaların üzerinde gösterme izni istenir. " +
                "Ekran görüntüleri dosyaya kaydedilmez."
            textSize = 12f
            setTextColor(Color.rgb(145, 160, 181))
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.rgb(25, 37, 55))
        }
        root.addView(note, matchWidthWrap())

        setContentView(scroll)
    }

    private fun addFieldLabel(parent: LinearLayout, label: String) {
        val view = TextView(this).apply {
            text = label
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(45, 212, 191))
            setPadding(0, dp(12), 0, dp(7))
        }
        parent.addView(view)
    }

    private fun createLanguageSpinner(): Spinner {
        val spinner = Spinner(this)
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            AppLanguages.all.map { it.title }
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
        return spinner
    }

    private fun beginPermissionFlow() {
        // Android 6+ requires a user-approved overlay permission for floating UI.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            setStatus("Devam etmek için Ekran Çevirici için 'Diğer uygulamaların üzerinde göster' iznini aç.")
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, REQUEST_OVERLAY)
            return
        }
        requestScreenCaptureConsent()
    }

    private fun requestScreenCaptureConsent() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        setStatus("Android ekran paylaşımı izni bekleniyor.")
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
    }

    @Deprecated("Android's consent activities are handled through onActivityResult for API 29 compatibility.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_OVERLAY -> {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
                    requestScreenCaptureConsent()
                } else {
                    setStatus("Üst katman izni verilmedi. Canlı çeviri başlatılamadı.")
                }
            }
            REQUEST_CAPTURE -> {
                if (resultCode == RESULT_OK && data != null) {
                    val source = AppLanguages[sourceSpinner.selectedItemPosition].code
                    val target = AppLanguages[targetSpinner.selectedItemPosition].code
                    val serviceIntent = Intent(this, CaptureService::class.java).apply {
                        action = AppContract.ACTION_START
                        putExtra(AppContract.EXTRA_RESULT_CODE, resultCode)
                        putExtra(AppContract.EXTRA_RESULT_DATA, data)
                        putExtra(AppContract.EXTRA_SOURCE_LANGUAGE, source)
                        putExtra(AppContract.EXTRA_TARGET_LANGUAGE, target)
                    }
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            startForegroundService(serviceIntent)
                        } else {
                            startService(serviceIntent)
                        }
                        setStatus("Canlı çeviri başlatılıyor. Diğer uygulamaya geçebilirsin.")
                    } catch (error: Exception) {
                        setStatus("Başlatma hatası: ${error.localizedMessage ?: "bilinmeyen hata"}")
                    }
                } else {
                    setStatus("Ekran paylaşımı izni verilmedi; çeviri başlamadı.")
                }
            }
        }
    }

    private fun stopCaptureService() {
        val intent = Intent(this, CaptureService::class.java).setAction(AppContract.ACTION_STOP)
        startService(intent)
    }

    private fun setStatus(message: String) {
        if (::statusText.isInitialized) statusText.text = message
    }

    private fun matchWidthWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
