package com.orbit.ekrancelviri

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.android.gms.tasks.Task
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Foreground screen-capture service.
 * Takes a frame once per second, performs on-device OCR, and translates only
 * when the recognized text differs from the previous frame.
 */
class CaptureService : Service() {

    private companion object {
        const val CHANNEL_ID = "screen_translate_live"
        const val NOTIFICATION_ID = 901
        const val FRAME_INTERVAL_MS = 1_000L
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val processingFrame = AtomicBoolean(false)

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var translator: Translator? = null
    private var windowManager: WindowManager? = null

    private var overlayRoot: LinearLayout? = null
    private var overlayOriginal: TextView? = null
    private var overlayTranslation: TextView? = null
    private var overlayStatus: TextView? = null
    private var overlayParams: WindowManager.LayoutParams? = null

    private var isRunning = false
    private var sourceLanguage = "en"
    private var targetLanguage = "tr"
    private var lastRecognizedText = ""
    private var emptyFrameCount = 0
    private var recognizers: List<TextRecognizer> = emptyList()

    private val frameLoop = object : Runnable {
        override fun run() {
            if (!isRunning) return
            captureOneFrame()
            mainHandler.postDelayed(this, FRAME_INTERVAL_MS)
        }
    }

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            isRunning = false
            mainHandler.post { stopSelf() }
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        createRecognizers()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == AppContract.ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action != AppContract.ACTION_START) return START_NOT_STICKY

        startForeground(NOTIFICATION_ID, buildNotification("Ekran izni hazırlanıyor…"))
        sourceLanguage = intent.getStringExtra(AppContract.EXTRA_SOURCE_LANGUAGE) ?: "en"
        targetLanguage = intent.getStringExtra(AppContract.EXTRA_TARGET_LANGUAGE) ?: "tr"
        val resultCode = intent.getIntExtra(AppContract.EXTRA_RESULT_CODE, 0)
        val resultData = getResultData(intent)

        if (resultData == null) {
            showOverlayStatus("Ekran yakalama bilgisi alınamadı. Uygulamayı yeniden başlat.")
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, resultData)
            if (projection == null) throw IllegalStateException("Android ekran paylaşımı başlatılamadı.")
            projection?.registerCallback(projectionCallback, mainHandler)
            showOverlay()
            startVirtualDisplay()
            prepareTranslator()
        } catch (error: Exception) {
            showOverlayStatus("Başlatma hatası: ${error.localizedMessage ?: "bilinmeyen hata"}")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun getResultData(intent: Intent): Intent? {
        return if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(AppContract.EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            intent.getParcelableExtra(AppContract.EXTRA_RESULT_DATA)
        }
    }

    private fun createRecognizers() {
        // Primary Latin recognizer covers English, Turkish and many European languages.
        // Fallback recognizers provide OCR for four additional writing systems.
        recognizers = listOf(
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS),
            TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build()),
            TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build()),
            TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()),
            TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        )
    }

    private fun startVirtualDisplay() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)

        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        virtualDisplay = projection?.createVirtualDisplay(
            "EkranCeviriciCapture",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            mainHandler
        ) ?: throw IllegalStateException("Sanal ekran oluşturulamadı.")
    }

    private fun prepareTranslator() {
        val source = TranslateLanguage.fromLanguageTag(sourceLanguage)
            ?: throw IllegalArgumentException("Kaynak dil desteklenmiyor: $sourceLanguage")
        val target = TranslateLanguage.fromLanguageTag(targetLanguage)
            ?: throw IllegalArgumentException("Hedef dil desteklenmiyor: $targetLanguage")

        if (sourceLanguage == targetLanguage) {
            showOverlayStatus("Kaynak ve hedef dil aynı. Metinler aynen gösterilecek.")
            isRunning = true
            mainHandler.post(frameLoop)
            return
        }

        val options = TranslatorOptions.Builder()
            .setSourceLanguage(source)
            .setTargetLanguage(target)
            .build()
        translator = Translation.getClient(options)
        showOverlayStatus("Dil modeli hazırlanıyor. İlk kullanımda indirme gerekebilir…")
        updateNotification("Çeviri dili modeli indiriliyor…")

        translator?.downloadModelIfNeeded(DownloadConditions.Builder().build())
            ?.addOnSuccessListener {
                if (!isRunning) {
                    isRunning = true
                    showOverlayStatus("Canlı çeviri etkin. Ekranda metin aranıyor…")
                    updateNotification("Canlı ekran çevirisi etkin")
                    mainHandler.post(frameLoop)
                }
            }
            ?.addOnFailureListener { error ->
                showOverlayStatus("Çeviri modeli indirilemedi: ${error.localizedMessage ?: "internet bağlantısını kontrol et"}")
                updateNotification("Çeviri modeli indirilemedi")
                stopSelf()
            }
    }

    private fun captureOneFrame() {
        if (!isRunning || !processingFrame.compareAndSet(false, true)) return

        val image = try {
            imageReader?.acquireLatestImage()
        } catch (_: Exception) {
            null
        }

        if (image == null) {
            processingFrame.set(false)
            return
        }

        var bitmap: Bitmap? = null
        try {
            bitmap = imageToBitmap(image)
        } catch (error: Exception) {
            showOverlayStatus("Ekran görüntüsü alınamadı: ${error.localizedMessage ?: "bilinmeyen hata"}")
        } finally {
            image.close()
        }

        if (bitmap == null) {
            processingFrame.set(false)
            return
        }
        runOcrWithFallback(bitmap, 0)
    }

    /** Converts the latest ImageReader frame to a cropped ARGB bitmap. */
    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val paddedWidth = image.width + rowPadding / pixelStride

        val paddedBitmap = Bitmap.createBitmap(
            paddedWidth,
            image.height,
            Bitmap.Config.ARGB_8888
        )
        buffer.rewind()
        paddedBitmap.copyPixelsFromBuffer(buffer)
        val cropped = Bitmap.createBitmap(paddedBitmap, 0, 0, image.width, image.height)
        paddedBitmap.recycle()
        return cropped
    }

    /** Tries each installed OCR script in order; stops on the first non-empty result. */
    private fun runOcrWithFallback(bitmap: Bitmap, recognizerIndex: Int) {
        if (recognizerIndex >= recognizers.size) {
            onOcrFinished(bitmap, "")
            return
        }

        val inputImage = InputImage.fromBitmap(bitmap, 0)
        val task: Task<com.google.mlkit.vision.text.Text> = recognizers[recognizerIndex].process(inputImage)
        task.addOnSuccessListener { result ->
            val detected = result.text.trim()
            if (detected.isNotEmpty() || recognizerIndex == recognizers.lastIndex) {
                onOcrFinished(bitmap, detected)
            } else {
                runOcrWithFallback(bitmap, recognizerIndex + 1)
            }
        }.addOnFailureListener { error ->
            if (recognizerIndex < recognizers.lastIndex) {
                runOcrWithFallback(bitmap, recognizerIndex + 1)
            } else {
                showOverlayStatus("OCR işlemi başarısız: ${error.localizedMessage ?: "metin okunamadı"}")
                onOcrFinished(bitmap, "")
            }
        }
    }

    private fun onOcrFinished(bitmap: Bitmap, detectedText: String) {
        try {
            bitmap.recycle()
        } catch (_: Exception) {
            // The bitmap may already have been released after an exceptional path.
        }

        val normalized = detectedText
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(3500)

        if (normalized.isEmpty()) {
            emptyFrameCount++
            if (emptyFrameCount >= 3 && lastRecognizedText.isEmpty()) {
                showOverlayStatus("Ekranda okunabilir metin aranıyor…")
            }
            processingFrame.set(false)
            return
        }

        emptyFrameCount = 0
        // Avoid unnecessary translation when the visible text has not changed.
        if (normalized == lastRecognizedText) {
            processingFrame.set(false)
            return
        }
        lastRecognizedText = normalized
        showOverlayOriginal(normalized)

        if (sourceLanguage == targetLanguage) {
            showOverlayTranslation(normalized)
            processingFrame.set(false)
            return
        }

        val activeTranslator = translator
        if (activeTranslator == null) {
            showOverlayStatus("Çeviri motoru hazır değil.")
            processingFrame.set(false)
            return
        }

        activeTranslator.translate(normalized)
            .addOnSuccessListener { translated ->
                showOverlayTranslation(translated)
                processingFrame.set(false)
            }
            .addOnFailureListener { error ->
                showOverlayStatus("Çeviri yapılamadı: ${error.localizedMessage ?: "dil modelini kontrol et"}")
                // Permit retry on the next frame if the translation operation failed.
                lastRecognizedText = ""
                processingFrame.set(false)
            }
    }

    private fun showOverlay() {
        val wm = windowManager ?: return
        if (overlayRoot != null) return

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(14))
            background = GradientDrawable().apply {
                setColor(Color.argb(238, 16, 24, 39))
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), Color.rgb(45, 212, 191))
            }
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val heading = TextView(this).apply {
            text = "CANLI ÇEVİRİ  •  SÜRÜKLE"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(45, 212, 191))
        }
        header.addView(heading, LinearLayout.LayoutParams(0, dp(38), 1f))

        val stopButton = Button(this).apply {
            text = "DURDUR"
            textSize = 10f
            isAllCaps = false
            setPadding(dp(8), 0, dp(8), 0)
            setOnClickListener {
                stopSelf()
            }
        }
        header.addView(stopButton, LinearLayout.LayoutParams(dp(82), dp(38)))
        panel.addView(header)

        val status = TextView(this).apply {
            text = "Dil modeli hazırlanıyor…"
            textSize = 11f
            setTextColor(Color.rgb(164, 180, 202))
            setPadding(0, dp(2), 0, dp(6))
        }
        panel.addView(status)
        overlayStatus = status

        val scroll = ScrollView(this).apply {
            isFillViewport = false
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val original = TextView(this).apply {
            text = "Algılanan metin burada görünecek."
            textSize = 12f
            setTextColor(Color.rgb(180, 193, 211))
            setPadding(0, dp(5), 0, dp(8))
        }
        val translated = TextView(this).apply {
            text = "Çeviri bekleniyor…"
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(0, dp(4), 0, dp(5))
        }
        content.addView(original)
        content.addView(translated)
        scroll.addView(content)
        panel.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(180)
        ))

        overlayOriginal = original
        overlayTranslation = translated
        overlayRoot = panel

        val params = WindowManager.LayoutParams(
            minOf(resources.displayMetrics.widthPixels - dp(24), dp(480)),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_SECURE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(70)
        }
        overlayParams = params

        // Drag the floating panel by touching its header area.
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        header.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - touchX).toInt()
                    params.y = (startY + (event.rawY - touchY).toInt()).coerceAtLeast(dp(8))
                    try { wm.updateViewLayout(panel, params) } catch (_: Exception) { }
                    true
                }
                else -> false
            }
        }

        try {
            wm.addView(panel, params)
        } catch (error: Exception) {
            overlayRoot = null
            showOverlayStatus("Üst katman açılamadı: ${error.localizedMessage ?: "izinleri kontrol et"}")
        }
    }

    private fun showOverlayStatus(message: String) {
        mainHandler.post {
            overlayStatus?.text = message
        }
    }

    private fun showOverlayOriginal(text: String) {
        mainHandler.post {
            overlayOriginal?.text = "Kaynak metin: $text"
        }
    }

    private fun showOverlayTranslation(text: String) {
        mainHandler.post {
            overlayTranslation?.text = text
            overlayStatus?.text = "Canlı çeviri • ${sourceLanguage.uppercase()} → ${targetLanguage.uppercase()}"
        }
    }

    private fun buildNotification(status: String): Notification {
        val stopIntent = Intent(this, CaptureService::class.java).setAction(AppContract.ACTION_STOP)
        val stopPendingIntent = PendingIntent.getService(
            this,
            77,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle("Ekran Çevirici")
            .setContentText(status)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_pause, "Durdur", stopPendingIntent).build())
            .build()
    }

    private fun updateNotification(status: String) {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(status))
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Canlı ekran çevirisi",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Ekran çevirisi çalışırken gösterilir."
        }
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(channel)
    }

    override fun onDestroy() {
        isRunning = false
        mainHandler.removeCallbacks(frameLoop)
        try { virtualDisplay?.release() } catch (_: Exception) { }
        virtualDisplay = null
        try { imageReader?.close() } catch (_: Exception) { }
        imageReader = null
        try {
            projection?.unregisterCallback(projectionCallback)
            projection?.stop()
        } catch (_: Exception) { }
        projection = null
        try { translator?.close() } catch (_: Exception) { }
        translator = null
        recognizers.forEach { recognizer ->
            try { recognizer.close() } catch (_: Exception) { }
        }
        recognizers = emptyList()
        removeOverlay()
        super.onDestroy()
    }

    private fun removeOverlay() {
        val view = overlayRoot
        if (view != null) {
            try { windowManager?.removeView(view) } catch (_: Exception) { }
        }
        overlayRoot = null
        overlayOriginal = null
        overlayTranslation = null
        overlayStatus = null
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
