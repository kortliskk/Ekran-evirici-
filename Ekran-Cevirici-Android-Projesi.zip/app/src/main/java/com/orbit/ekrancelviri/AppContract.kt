package com.orbit.ekrancelviri

/** Shared action and extra names used by the Activity and foreground service. */
object AppContract {
    const val ACTION_START = "com.orbit.ekrancelviri.action.START"
    const val ACTION_STOP = "com.orbit.ekrancelviri.action.STOP"
    const val EXTRA_RESULT_CODE = "extra_result_code"
    const val EXTRA_RESULT_DATA = "extra_result_data"
    const val EXTRA_SOURCE_LANGUAGE = "extra_source_language"
    const val EXTRA_TARGET_LANGUAGE = "extra_target_language"
}

data class AppLanguage(val title: String, val code: String)

/** ML Kit Translation's currently listed language set (59 language tags). */
object AppLanguages {
    val all = listOf(
        AppLanguage("Afrikaans", "af"),
        AppLanguage("Arnavutça", "sq"),
        AppLanguage("Arapça", "ar"),
        AppLanguage("Belarusça", "be"),
        AppLanguage("Bengalce", "bn"),
        AppLanguage("Bulgarca", "bg"),
        AppLanguage("Katalanca", "ca"),
        AppLanguage("Çince", "zh"),
        AppLanguage("Çekçe", "cs"),
        AppLanguage("Galce", "cy"),
        AppLanguage("Danca", "da"),
        AppLanguage("Almanca", "de"),
        AppLanguage("Yunanca", "el"),
        AppLanguage("İngilizce", "en"),
        AppLanguage("Esperanto", "eo"),
        AppLanguage("İspanyolca", "es"),
        AppLanguage("Estonca", "et"),
        AppLanguage("Farsça", "fa"),
        AppLanguage("Fince", "fi"),
        AppLanguage("Fransızca", "fr"),
        AppLanguage("İrlandaca", "ga"),
        AppLanguage("Galiçyaca", "gl"),
        AppLanguage("Guceratça", "gu"),
        AppLanguage("İbranice", "he"),
        AppLanguage("Hintçe", "hi"),
        AppLanguage("Hırvatça", "hr"),
        AppLanguage("Haitice", "ht"),
        AppLanguage("Macarca", "hu"),
        AppLanguage("Endonezce", "id"),
        AppLanguage("İzlandaca", "is"),
        AppLanguage("İtalyanca", "it"),
        AppLanguage("Japonca", "ja"),
        AppLanguage("Gürcüce", "ka"),
        AppLanguage("Kannada", "kn"),
        AppLanguage("Korece", "ko"),
        AppLanguage("Litvanca", "lt"),
        AppLanguage("Letonca", "lv"),
        AppLanguage("Makedonca", "mk"),
        AppLanguage("Marathi", "mr"),
        AppLanguage("Malayca", "ms"),
        AppLanguage("Maltaca", "mt"),
        AppLanguage("Felemenkçe", "nl"),
        AppLanguage("Norveççe", "no"),
        AppLanguage("Lehçe", "pl"),
        AppLanguage("Portekizce", "pt"),
        AppLanguage("Romence", "ro"),
        AppLanguage("Rusça", "ru"),
        AppLanguage("Slovakça", "sk"),
        AppLanguage("Slovence", "sl"),
        AppLanguage("İsveççe", "sv"),
        AppLanguage("Svahili", "sw"),
        AppLanguage("Tamilce", "ta"),
        AppLanguage("Teluguca", "te"),
        AppLanguage("Tayca", "th"),
        AppLanguage("Tagalog", "tl"),
        AppLanguage("Türkçe", "tr"),
        AppLanguage("Ukraynaca", "uk"),
        AppLanguage("Urduca", "ur"),
        AppLanguage("Vietnamca", "vi")
    )
}
